<?php
    echo $_POST['avatar'];
  exit(json_encode($_FILES['avatar']));
?>
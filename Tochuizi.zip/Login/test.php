<?php 
echo md5(date('Ymd').'login'.'tuchuinet');

?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>卖家中心-招聘管理</title>
	<meta name="viewport" id="viewport" content="width=device-width, initial-scale=1">
	 <link rel="stylesheet" href="../Public/css/weui.min.css"/>
	 <link rel="stylesheet" href="../Public/css/weui.min.0.4.3.css"/>
	 	<link rel="stylesheet" href="../Public/css/jquery-weui.min.css">
        <link rel="stylesheet" href="../Public/css/center.css"/>
          <link rel="stylesheet" type="text/css" href="../Public/font/iconfont.css">
          <link rel="stylesheet" href="../Public/css/common.css"/>
         <link rel="stylesheet" type="text/css" href="../Public/css/business.css"/>
</head>
<body >
<div id="app">
 		<div id="topback-header">
 				<div id="header-left">
	 				 <a href="javascript:history.go(-1);" >
	                      <i class="icon iconfont icon-xiangzuo"></i>
	                  	    <span class="title">我的招聘</span>
	               	 </a>
 				</div>
                <div id="header-right">
                	<a href="editEmploy.php"><img alt="" src="../Public/img/business/addEmploy.png"></a>
                </div>
		</div>
		<div class="employ">
		<div class="weui_cells weui_cells_access">
		  <a class="weui_cell" href="editEmploy.html">
		    <div class="weui_cell_bd weui_cell_primary">
		       <p><span>诚招店员</span><span>1000元</span></p>
		    </div>
		    <div class="weui_cell_ft"><span>5天前</span></div>
		  </a>
		  <a class="weui_cell" href="editEmploy.html">
		    <div class="weui_cell_bd weui_cell_primary">
		       <p>专业版和普通版区别，专业版收费</p>
		    </div>
		    <div class="weui_cell_ft"><span>5天前</span></div>
		  </a>
		</div>
		</div>
	</div>
</body>
<script src="../Public/js/jquery-2.1.4.js"></script>
<script src="../Public/js/jquery-weui.min.js"></script>
<script>
 	

</script>
</html>
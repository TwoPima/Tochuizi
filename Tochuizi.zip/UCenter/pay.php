<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>个人主页-订单中心</title>
	<meta name="viewport" id="viewport" content="width=device-width, initial-scale=1">
	 <link rel="stylesheet" href="../Public/css/weui.min.css"/>
	 <link rel="stylesheet" href="../Public/css/weui.min.0.4.3.css"/>
	 	<link rel="stylesheet" href="../Public/css/jquery-weui.min.css">
          <link rel="stylesheet" type="text/css" href="../Public/font/iconfont.css">
          <link rel="stylesheet" href="../Public/css/common.css"/>
        <link rel="stylesheet" href="../Public/css/center.css"/>
</head>
<body >
	<div id="app">
		<div id="topback-header">
 				<div id="header-left">
	 				 <a href="javascript:history.go(-1);" >
	                      <i class="icon iconfont icon-xiangzuo"></i>
	                  	    <span class="title">提交订单</span>
	               	 </a>
 				</div>
                <div id="header-right">
                </div>
		</div>
		<div id="submitOrder">
			<div class="order-content">
				<div class="weui_cells">
				
				  <div class="weui_cell">
				    <div class="weui_cell_bd weui_cell_primary">
				      <p>银川兴庆区海上国际3吨</p>
				    </div>
				    <div class="weui_cell_ft">
				 	     <span class="price"><span id="key">￥1200</span><span id="val">x1</span></span>
				 	     <span  class="freight"><span id="key">运费</span><span id="val">￥10</span></span>
				    </div>
				  </div>
				  <div class="weui_cell">
				    <div class="weui_cell_bd weui_cell_primary">
				      <p>银川兴庆区海上国际3吨</p>
				    </div>
				    <div class="weui_cell_ft">
				 	     <span class="price"><span id="key">￥1200</span><span id="val">x1</span></span>
				 	     <span  class="freight"><span id="key">运费</span><span id="val">￥10</span></span>
				    </div>
				  </div>
				  <div class="weui_cell">
				    <div class="weui_cell_bd weui_cell_primary">
				      <p>银川兴庆区海上国际3吨</p>
				    </div>
				    <div class="weui_cell_ft">
				 	     <span class="price"><span id="key">￥1200</span><span id="val">x1</span></span>
				 	     <span  class="freight"><span id="key">运费</span><span id="val">￥10</span></span>
				    </div>
				  </div>
				    <div class="weui_panel_ft count"><span class="key float-left">合计支付</span><span class="val float-right">￥2333.00</span></div>
				</div>
			</div>
			<div class="pay-method">
				<div class="weui_panel weui_panel_access">
				  <div class="weui_panel_hd"><i class="icon iconfont icon-zhifu"></i><span>选择支付方式</span></div>
				  <div class="weui_panel_bd">
				    <div class="weui_media_box">
				      <div ><img class="method float-left" src="../Public/img/order/zhifubao.png"/></div>
				      <div ><img class="method float-right"src="../Public/img/order/weixin.png"/></div>
				      <div ><img class="method clear last-one-img"src="../Public/img/order/yinlian.png"/></div>
				    </div>
				  </div>
				</div>
			</div>
			<div class="height20px"></div>
            <div class="button-sp-area">
                <a href="javascript:;" class="weui-btn weui-btn_plain-default "id="btn-custom-theme">提&nbsp;&nbsp;&nbsp;&nbsp;交</a>
            </div>
		</div>
	</div>
</body>
  <script src="../Public/js/zepto.js"></script>
<script src="../Public/js/vue.2.1.0.js"></script>
<script src="../Public/js/jquery-2.1.4.js"></script>
<script src="../Public/js/jquery-weui.min.js"></script>
<script>
</script>
</html>
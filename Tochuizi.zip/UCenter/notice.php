 <div class="menu">
        <ul class="menu1">
            <li class="home_page"><a href="#"></a></li>
            <li><a href="#">首页</a></li>
        </ul>
        <ul class="menu2">
            <li class="supply"><a href="#"></a></li>
            <li><a href="">供求</a></li>
        </ul>
        <ul class="menu3">
            <li class="my"><a href="#"></a></li>
            <li><a href="">我的</a></li>
        </ul>
    </div>
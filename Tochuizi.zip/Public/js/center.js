var lang_flag = 1;  
function fun()  
{  
    document.write(like[lang_flag]);  
} 

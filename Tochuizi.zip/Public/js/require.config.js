//    HOST = "http://www.tigerjob.com",
    //HOST = "http://tcw.huikenet.com/";
    HOST = "http://121.42.207.20/";
   // PATH = "/";
